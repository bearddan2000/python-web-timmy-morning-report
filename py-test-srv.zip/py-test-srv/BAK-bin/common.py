import requests, testify

URL = "http://py-srv:5000"

def assert_url(url: str):
    """assert that endpoint is valid"""
    
    resp = requests.get(url)

    testify.assert_equal(resp.status_code, 200)

    return 0