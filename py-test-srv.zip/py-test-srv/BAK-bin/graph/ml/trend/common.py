from graph.ml.common import URL

URL += '/trend'