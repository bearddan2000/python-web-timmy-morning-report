from common import assert_url
import unittest

from graph.ml.forecast.common import URL
 
class TestURLStatus(unittest.TestCase):
    """docstring for TestStatus."""

    def test_short_url_status(self):
        return assert_url(URL+'/3')

    def test_mid_url_status(self):
        return assert_url(URL+'/7')

    def test_long_url_status(self):
        return assert_url(URL+'/30')