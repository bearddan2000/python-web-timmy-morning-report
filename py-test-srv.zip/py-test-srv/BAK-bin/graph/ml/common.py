from graph.common import URL

URL += '/ml'