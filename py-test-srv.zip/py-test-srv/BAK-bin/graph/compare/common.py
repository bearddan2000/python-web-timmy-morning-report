from graph.common import URL

URL += '/compare'