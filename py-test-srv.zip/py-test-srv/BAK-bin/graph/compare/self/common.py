from graph.compare.common import URL

URL += '/self'