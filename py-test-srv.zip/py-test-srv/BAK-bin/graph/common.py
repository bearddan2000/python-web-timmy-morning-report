from common import URL

URL += '/graph'