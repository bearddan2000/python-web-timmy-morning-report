from graph.scatter.common import SUFFIX

SUFFIX += '/bedtime'