from graph.heat.common import SUFFIX

SUFFIX += '/sleep'