from graph.csd.common import SUFFIX

SUFFIX += '/bedtime'