from graph.csd.common import SUFFIX

SUFFIX += '/sleep'