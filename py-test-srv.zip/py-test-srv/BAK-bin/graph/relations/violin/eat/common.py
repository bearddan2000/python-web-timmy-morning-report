from graph.violin.common import SUFFIX

SUFFIX += '/eat'