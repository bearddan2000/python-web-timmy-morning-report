from common import assert_url
from graph.relations.common import URL
from graph.relations.violin.eat import SUFFIX
import unittest

SUFFIX += '/morning'
 
class TestURLStatus(unittest.TestCase):
    """docstring for TestStatus."""

    def test_current_url_status(self):
        return assert_url(URL+'/current'+SUFFIX)

    def test_prev_url_status(self):
        return assert_url(URL+'/prev'+SUFFIX)

    def test_ytd_url_status(self):
        return assert_url(URL+'/ytd'+SUFFIX)

class TestMonthURLStatus(unittest.TestCase):
    MONTH = URL + '/month'

    def test_jan_url_status(self):
        return assert_url(self.MONTH+'/1'+SUFFIX)

    def test_feb_url_status(self):
        return assert_url(self.MONTH+'/2'+SUFFIX)
    
    def test_mar_url_status(self):
        return assert_url(self.MONTH+'/3'+SUFFIX)

class TestWeekdayURLStatus(unittest.TestCase):
    WKDAY = URL + '/weekday'

    def test_mon_url_status(self):
        return assert_url(self.WKDAY+'/0'+SUFFIX)

    def test_tue_url_status(self):
        return assert_url(self.WKDAY+'/1'+SUFFIX)

    def test_wed_url_status(self):
        return assert_url(self.WKDAY+'/2'+SUFFIX)
    
    def test_thur_url_status(self):
        return assert_url(self.WKDAY+'/3'+SUFFIX)

    def test_fri_url_status(self):
        return assert_url(self.WKDAY+'/4'+SUFFIX)
    