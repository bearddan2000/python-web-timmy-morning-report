from graph.violin.common import SUFFIX

SUFFIX += '/bedtime'