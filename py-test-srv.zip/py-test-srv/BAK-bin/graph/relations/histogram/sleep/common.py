from graph.histogram.common import SUFFIX

SUFFIX += '/sleep'