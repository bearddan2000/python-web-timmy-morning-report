from graph.histogram.common import SUFFIX

SUFFIX += '/eat'