from graph.cluster.common import SUFFIX

SUFFIX += '/bedtime'