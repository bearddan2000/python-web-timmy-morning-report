from graph.cluster.common import SUFFIX

SUFFIX += '/eat'