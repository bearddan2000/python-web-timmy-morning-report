from graph.common import URL

URL += '/relations'