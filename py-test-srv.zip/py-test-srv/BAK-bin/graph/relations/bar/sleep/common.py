from graph.bar.common import SUFFIX

SUFFIX += '/sleep'