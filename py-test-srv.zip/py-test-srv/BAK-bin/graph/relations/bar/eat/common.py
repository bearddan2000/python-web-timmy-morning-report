from graph.bar.common import SUFFIX

SUFFIX += '/eat'