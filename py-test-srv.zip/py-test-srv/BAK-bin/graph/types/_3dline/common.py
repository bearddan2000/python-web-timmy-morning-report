from graph.types.common import URL

URL += '/3dline'