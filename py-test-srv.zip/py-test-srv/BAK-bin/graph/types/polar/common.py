from graph.types.common import URL

URL += '/polar'