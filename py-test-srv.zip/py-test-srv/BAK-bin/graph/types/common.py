from graph.common import URL

URL += '/types'