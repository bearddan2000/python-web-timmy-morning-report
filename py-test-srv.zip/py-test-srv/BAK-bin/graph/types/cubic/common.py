from graph.types.common import URL

URL += '/cubic'