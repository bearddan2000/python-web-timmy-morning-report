from graph.distribution.common import URL

URL += '/3dcumulative/none'