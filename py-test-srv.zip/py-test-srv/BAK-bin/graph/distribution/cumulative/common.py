from graph.distribution.common import URL

URL += '/cumulative/bar'