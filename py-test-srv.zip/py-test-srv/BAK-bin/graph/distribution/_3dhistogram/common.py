from graph.distribution.common import URL

URL += '/3dhistogram/none'