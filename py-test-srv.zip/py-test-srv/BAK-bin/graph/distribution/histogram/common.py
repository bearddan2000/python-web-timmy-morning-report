from graph.distribution.common import URL

URL += '/histogram/bar'