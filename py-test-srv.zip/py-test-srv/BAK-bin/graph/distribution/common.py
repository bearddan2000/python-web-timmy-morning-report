from graph.common import URL

URL += '/distribution'