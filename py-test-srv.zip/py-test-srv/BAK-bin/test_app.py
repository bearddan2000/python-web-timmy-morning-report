from common import URL, assert_url
import unittest
 
class TestURLStatus(unittest.TestCase):
    """docstring for TestStatus."""

    def test_current_url_status(self):
        return assert_url(URL+'/current')

    def test_historical_url_status(self):
        return assert_url(URL+'/historical')
    