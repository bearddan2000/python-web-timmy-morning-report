from stats.common import URL

URL += '/trends'