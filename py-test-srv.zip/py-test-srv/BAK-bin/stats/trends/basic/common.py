from stats.trends.common import URL

URL += '/basic'