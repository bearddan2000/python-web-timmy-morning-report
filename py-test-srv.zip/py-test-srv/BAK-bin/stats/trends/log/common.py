from stats.trends.common import URL

URL += '/log'