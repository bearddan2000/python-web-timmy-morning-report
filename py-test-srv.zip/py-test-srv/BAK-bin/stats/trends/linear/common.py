from stats.trends.common import URL

URL += '/linear'