from common import assert_url
import unittest

from stats.trends.linear.common import URL
 
class TestURLStatus(unittest.TestCase):
    """docstring for TestStatus."""

    def test_current_url_status(self):
        return assert_url(URL+'/current')

    def test_prev_url_status(self):
        return assert_url(URL+'/prev')

    def test_ytd_url_status(self):
        return assert_url(URL+'/ytd')

class TestMonthURLStatus(unittest.TestCase):
    MONTH = URL + '/month'

    def test_jan_url_status(self):
        return assert_url(self.MONTH+'/1')

    def test_feb_url_status(self):
        return assert_url(self.MONTH+'/2')
    
    def test_mar_url_status(self):
        return assert_url(self.MONTH+'/3')

class TestWeekdayURLStatus(unittest.TestCase):
    WKDAY = URL + '/weekday'

    def test_mon_url_status(self):
        return assert_url(self.WKDAY+'/0')

    def test_tue_url_status(self):
        return assert_url(self.WKDAY+'/1')

    def test_wed_url_status(self):
        return assert_url(self.WKDAY+'/2')
    
    def test_thur_url_status(self):
        return assert_url(self.WKDAY+'/3')

    def test_fri_url_status(self):
        return assert_url(self.WKDAY+'/4')
    