from stats.common import URL

URL += '/correlation'