from stats.common import URL

URL += '/datatable'