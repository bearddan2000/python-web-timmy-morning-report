from stats.common import URL

URL += '/prediction/regression'