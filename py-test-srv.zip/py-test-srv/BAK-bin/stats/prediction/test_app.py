from common import assert_url
import unittest

from stats.prediction.common import URL
 
class TestURLStatus(unittest.TestCase):
    """docstring for TestStatus."""

    def test_linear_url_status(self):
        return assert_url(URL+'/linear')

    def test_expo_url_status(self):
        return assert_url(URL+'/expo')

    def test_log_url_status(self):
        return assert_url(URL+'/log')