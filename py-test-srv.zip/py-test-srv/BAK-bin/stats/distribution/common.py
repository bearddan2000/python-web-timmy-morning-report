from stats.common import URL

URL += '/distribution'