from stats.distribution.common import URL

URL += '/frequency'