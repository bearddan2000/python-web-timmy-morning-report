from common import URL

URL += '/stats'